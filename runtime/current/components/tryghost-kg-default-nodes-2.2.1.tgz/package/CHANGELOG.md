# @tryghost/kg-default-nodes

## 2.2.1

### Patch Changes

- Updated Ghost docs links to new URLs

## 2.2.0

### Minor Changes

- Update jsdom to 30 & node engines to match jsdom's

### Patch Changes

- Removed the unused emailCustomization and emailCustomizationAlpha feature options.

- Documented the package API and corrected the development instructions in the README
